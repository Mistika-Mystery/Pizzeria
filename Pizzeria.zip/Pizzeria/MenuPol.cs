﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizzeria
{
    public partial class MenuPol : Form
    {
        public MenuPol()
        {
            InitializeComponent();
        }

        private void Menu_Click(object sender, EventArgs e)
        {

        }

        private void Akcii_Click(object sender, EventArgs e)
        {

        }

        private void Otzivi_Click(object sender, EventArgs e)
        {

        }
    }
}
